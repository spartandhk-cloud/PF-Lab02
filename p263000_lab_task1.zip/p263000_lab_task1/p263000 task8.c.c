#include <stdio.h>

int main(){

double principal = 250000.00;
float rate = 8.5;
int time = 3;

float simple_interest = (principal * time * rate)/100.0;
float total_payable_amount = principal + simple_interest;
float monthly_installment =  total_payable_amount/(time * 12.0);

 printf("================ BANK LOAN INTEREST SUMMARY ================/n");
 printf("Principal amount:\t(pkr)\t%.2lf\n",principal);
 printf("Annual Interest Rate:\t%.2f (%%)\n",rate);
 printf("Annual Interest Rate:\t%d (years)",time);
 printf("------------------------------------------------------------\n");
 printf("Total Accrued Interest:\t(pkr)\t%.2f\n",simple_interest);
 printf("Total Payable Amount:\t(pkr)\t%.2f\n",total_payable_amount);
 printf("Monthly Installment:\t(pkr)\t%.2f\n",monthly_installment);
 printf("============================================================\n");

    return 0;
}