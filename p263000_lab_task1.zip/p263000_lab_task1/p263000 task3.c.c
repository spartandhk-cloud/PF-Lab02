#include<stdio.h>

int main() {


 printf("================ C ESCAPE SEQUENCES REFERENCE================\n");
 printf("1. To print a double quote,write:\\\"\n");
 printf("2. To print a literal backlash,write:\\\\\n");
 printf("3. To insert a newline break,write:\\n\n");
 printf("4. To insert a horizontal tab stop,write:\\t\n");
 printf("5. To print a percent sign,write:%%%%\n");

printf("=================================================================\n");


    return 0;
}