#include <stdio.h>

int main() 
{

char  c = 'M';
int i = 42;
float f = 3.141590;
double d = 98.765432;

printf("Type Name\t\tVariable Value\t\tsize in Memory\n");
printf("------------------------------------------------------\n");
printf("Char\t\t\t%c\t\t\t\t\t 1 byte(s)\n", c);
printf("int\t\t\t\t%d\t\t\t\t\t 4 byte(s)\n", i);
printf("float\t\t\t%f\t\t\t 4 byte(s)\n", f);
printf("double\t\t\t%lf\t\t\t 8 byte(s)\n", d);
printf("------------------------------------------------------\n");

 return 0;
}