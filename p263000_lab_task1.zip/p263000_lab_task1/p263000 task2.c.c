#include<stdio.h>

int main() {


int batch = 2026;
char section = 'A';
float entrytest_score = 56.7;
double semester_fee = 168000.43;

 printf("====================================================\n");
 printf("FAST-NUCES STUDENT PROFILE CARD\n");
 printf("====================================================\n");
 
 
 printf("Batch year:\t%d\n",batch);
 printf("Section:\t%c\n",section);
 printf("Test score:\t%.2f\n",entrytest_score);
 printf("Semester fee:\tPkr %.2lf\n",semester_fee);
 printf("MOTTO:\t\t\"Small daily steps lead to big success\"\n");

 printf("====================================================\n");

return 0;

}