#include<stdio.h>
int main(){

float Pf_marks = 88.0;
int Pf_credits = 3;
float calc_marks = 76.5;
int calc_credits = 3;
float physics_marks = 82.0;
int physics_credits = 2;
float Total_Weighted_Score = (88.0 * 3) + (76.5 * 3) + (82.0 * 2);
int Total_Credit_Hours = 3+3+2;
float Weighted_Average_Percentage = Total_Weighted_Score/Total_Credit_Hours;
printf("================ SEMESTER ACADEMIC REPORT =================\n");
printf("Course\t\t\tCredit hours\t\tObtained marks\n");
printf("-----------------------------------------------------------\n");
printf("Programming Fund\t\t%d\t\t\t%.2f\n",Pf_credits, Pf_marks);
printf("Calculus\t\t\t\t%d\t\t\t%.2f\n",calc_credits, calc_marks);
printf("Applied Physics\t\t\t%d\t\t\t%.2f\n",physics_credits, physics_marks);
printf("-----------------------------------------------------------\n");
printf("Total Credits: %d\t\tWeighted Average: %.2f%%\n",Total_Credit_Hours, Weighted_Average_Percentage);
printf("===========================================================\n");
    return 0;
}