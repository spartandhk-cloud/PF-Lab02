#include <stdio.h>

int main(){

double basic_salary = 85000.00;

float house_rent_allowance = (0.20 * basic_salary);
float Medical_Allowance = (0.10 * basic_salary);
float Gross_Salary =  house_rent_allowance + Medical_Allowance;
float Income_Tax_Deduction = (0.5 * Gross_Salary);
float Net_Salary = Gross_Salary -  Income_Tax_Deduction;

printf("================= MONTHLY SALARY SLIP ==================\n");
printf("Basic Salary:\t\t(pkr)\t%.2lf\n",basic_salary);
printf("House Rent Allowance (20%):\t(pkr)\t%.2f\n",house_rent_allowance);
printf("Medical Allowance (10%):\t(pkr)\t%.2f\n",Medical_Allowance);
printf("--------------------------------------------------------\n");
printf("Gross Salary:\t\t(pkr)\t%.2f\n",Gross_Salary);
printf("Tax Deduction (5%):\t(pkr)\t%.2f\n",Income_Tax_Deduction);
printf("--------------------------------------------------------\n");
printf("Net Payable Salary:\t(pkr)\t%.2f\n",Net_Salary);
printf("========================================================\n");

    return 0;
}