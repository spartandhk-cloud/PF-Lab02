#include <stdio.h>
int main() {
    int qnt_tea = 3;
    float price_tea = 60.00;
    int qnt_samosa = 4;
    float price_samosa = 40.50;
    int qnt_roll = 2;
    float price_roll = 120.00;
    float subtotal_tea = qnt_tea * price_tea;  
    float subtotal_samosa = qnt_samosa * price_samosa; 
    float subtotal_roll = qnt_roll * price_roll; 
    float bill_subtotal = subtotal_tea + subtotal_samosa + subtotal_roll;
    float gst_amount = 0.16f * bill_subtotal;
    float grand_total = bill_subtotal + gst_amount;
    printf("================== FAST CAFETERIA RECEIPT ==================\n");
    printf("Item\t\tQty\t\t\tUnit Price (PKR)\tSubtotal (PKR)\n");
    printf("------------------------------------------------------------\n");
    printf("Tea\t\t\t%d\t\t\t%.2f\t\t\t\t%.2f\n", qnt_tea, price_tea, subtotal_tea);
    printf("Samosa\t\t%d\t\t\t%.2f\t\t\t\t%.2f\n", qnt_samosa, price_samosa, subtotal_samosa);
    printf("ChickenRoll\t%d\t\t\t%.2f\t\t\t\t%.2f\n", qnt_roll, price_roll, subtotal_roll);
    printf("------------------------------------------------------------\n");
    printf("Subtotal:\tPKR %.2f\n", bill_subtotal);
    printf("GST (16%%):\tPKR %.2f\n", gst_amount);
    printf("------------------------------------------------------------\n");
    printf("Grand Total:\tPKR %.2f\n", grand_total);
    printf("================= THANK YOU FOR YOUR VISIT =================\n");
    return 0;
}