#include <stdio.h>

int main() { 
 float initial_velocity = 12.5;
 float accelaration = 3.2;
 float time = 6.0;

 float final_velocity = initial_velocity + (accelaration * time);
 float total_distance = (initial_velocity * time) + (0.5 *accelaration * time * time);

 printf("================ KINEMATICS MOTION REPORT ===============\n");
 printf("Initial velocity (vi):\t%.2f\n",initial_velocity);
 printf("Accelaration (a):\t\t%.2f\n",accelaration);
 printf("Time Elapsed (t):\t\t%.2f\n",time);
 printf("=========================================================\n");
 printf("Calculated Final Velocity (vf):\t%.2f\n",final_velocity);
 printf("Calculated Distance (s):\t%.2f\n",total_distance);

    return 0;
}